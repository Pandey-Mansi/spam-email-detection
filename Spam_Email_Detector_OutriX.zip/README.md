
# 📧 Spam Email Detection using Machine Learning

This project is part of my Artificial Intelligence Internship at **OutriX**. It involves building a spam email classifier using NLP and machine learning techniques.

## 🔍 Overview
The goal is to classify SMS messages as spam or ham using TF-IDF and a Naive Bayes classifier.

## 📌 Tools & Libraries
- Python
- Pandas
- NLTK
- Scikit-learn
- Jupyter Notebook

## ⚙️ Features
- Preprocessing of email text
- TF-IDF vectorization
- Classification using Multinomial Naive Bayes
- Model evaluation using accuracy & classification report

## 🚀 How to Run
```bash
pip install pandas scikit-learn nltk
python spam_email_detector.py
```

## ✅ Output
- Accuracy: ~95-98%
- Detailed classification report

## 📹 Demo
A video demo has been posted on [LinkedIn](#) as part of the internship submission.

## 📬 Connect
If you have any queries, feel free to connect with me!
